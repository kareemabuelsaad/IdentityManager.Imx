import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, FilterData, FilterTreeData, FkProviderItem, InteractiveEntityData, InteractiveEntityWriteData, IReadValue, IWriteValue, MethodDescriptor, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface RoleAssignmentData {
    TableName?: string;
    TableDisplay?: string;
    UnionTableName?: string;
    UnionTableDisplay?: string;
    AssignTable?: string;
    RoleTable?: string;
    RoleFk?: string;
    EntitlementPk?: string;
    EntitlementFk?: string;
}
export declare class TypedClient {
    readonly PortalAdminRoleEset: PortalAdminRoleEsetWrapper;
    readonly PortalAdminRoleEsetInteractive: PortalAdminRoleEsetInteractiveWrapper;
    readonly PortalPersonRolemembershipsEset: PortalPersonRolemembershipsEsetWrapper;
    readonly PortalRespEset: PortalRespEsetWrapper;
    readonly PortalRespEsetInteractive: PortalRespEsetInteractiveWrapper;
    readonly PortalRolesConfigEntitlementsEset: PortalRolesConfigEntitlementsEsetWrapper;
    readonly PortalRolesConfigMembershipEset: PortalRolesConfigMembershipEsetWrapper;
    readonly PortalShopConfigEntitlementsEset: PortalShopConfigEntitlementsEsetWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalAdminRoleEset extends TypedEntity {
    readonly UID_AccProduct: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'RiskIndexCalculated' | 'XObjectKey'>;
}
/** @deprecated Use the PortalAdminRoleEset type. */
export declare class PortalAdminRoleEsetInteractive extends PortalAdminRoleEset {
}
export declare class PortalPersonRolemembershipsEset extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_ESet: IReadValue<string>;
    readonly RoleFullPath: IReadValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'UID_ESet' | 'RoleFullPath' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
/** @deprecated Use the PortalPersonRolemembershipsEset type. */
export declare class PortalPersonRolemembershipsEsetInteractive extends PortalPersonRolemembershipsEset {
}
export declare class PortalRespEset extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey'>;
}
/** @deprecated Use the PortalRespEset type. */
export declare class PortalRespEsetInteractive extends PortalRespEset {
}
export declare class PortalRolesConfigEntitlementsEset extends TypedEntity {
    readonly UID_ESet: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly Entitlement: IWriteValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ESet' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'XMarkedForDeletion' | 'Entitlement' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
/** @deprecated Use the PortalRolesConfigEntitlementsEset type. */
export declare class PortalRolesConfigEntitlementsEsetInteractive extends PortalRolesConfigEntitlementsEset {
}
export declare class PortalRolesConfigMembershipEset extends TypedEntity {
    readonly UID_ESet: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XIsInEffect: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly UID_Person: IWriteValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ESet' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'XIsInEffect' | 'XMarkedForDeletion' | 'UID_Person' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
/** @deprecated Use the PortalRolesConfigMembershipEset type. */
export declare class PortalRolesConfigMembershipEsetInteractive extends PortalRolesConfigMembershipEset {
}
export declare class PortalShopConfigEntitlementsEset extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_ESet: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_ESet'>;
}
/** @deprecated Use the PortalShopConfigEntitlementsEset type. */
export declare class PortalShopConfigEntitlementsEsetInteractive extends PortalShopConfigEntitlementsEset {
}
export declare class PortalAdminRoleEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalAdminRoleEset;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_admin_role_eset_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleEset, unknown>>;
    Put(inputParameterName: PortalAdminRoleEset, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleEset, unknown>>;
    Post(inputParameterName: PortalAdminRoleEset, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleEset, unknown>>;
}
export declare class PortalAdminRoleEsetInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalAdminRoleEset, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleEset, unknown>>;
    Get_byid(UID_ESet: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleEset, unknown>>;
    Get(parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleEset, unknown>>;
}
export declare class PortalPersonRolemembershipsEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Person: string, parametersOptional?: portal_person_rolememberships_ESet_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonRolemembershipsEset, unknown>>;
}
export declare class PortalRespEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_resp_eset_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespEset, unknown>>;
}
export declare class PortalRespEsetInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalRespEset, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespEset, unknown>>;
    Get_byid(UID_ESet: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespEset, unknown>>;
}
export declare class PortalRolesConfigEntitlementsEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalRolesConfigEntitlementsEset;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ESet: string, parametersOptional?: portal_roles_config_entitlements_ESet_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigEntitlementsEset, unknown>>;
    Post(UID_ESet: string, inputParameterName: PortalRolesConfigEntitlementsEset, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigEntitlementsEset, unknown>>;
    Delete(UID_ESet: string, UID_ESetHasEntitlement: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigEntitlementsEset, unknown>>;
}
export declare class PortalRolesConfigMembershipEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalRolesConfigMembershipEset;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ESet: string, parametersOptional?: portal_roles_config_membership_ESet_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigMembershipEset, unknown>>;
    Post(UID_ESet: string, inputParameterName: PortalRolesConfigMembershipEset, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigMembershipEset, unknown>>;
    Delete(UID_ESet: string, UID_Person: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigMembershipEset, unknown>>;
}
export declare class PortalShopConfigEntitlementsEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsEset;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: portal_shop_config_entitlements_ESet_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsEset, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsEset, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsEset, unknown>>;
    Delete(UID_ITShopOrg: string, UID_ESet: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsEset, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_admin_role_eset_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, risk: string, esettype: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_eset_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_eset_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_eset_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_admin_role_eset_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_admin_role_eset_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_eset_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_eset_interactive_byid_get(UID_ESet: string): MethodDescriptor<InteractiveEntityData>;
    portal_person_rolememberships_ESet_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_eset_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, esettype: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_eset_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_eset_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_resp_eset_interactive_byid_get(UID_ESet: string): MethodDescriptor<InteractiveEntityData>;
    portal_roles_config_classes_ESet_get(): MethodDescriptor<RoleAssignmentData[]>;
    portal_roles_config_entitlements_ESet_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_post(UID_ESet: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_delete(UID_ESet: string, UID_ESetHasEntitlement: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_roles_config_membership_ESet_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_post(UID_ESet: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_delete(UID_ESet: string, UID_Person: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_UID_Person_candidates_get(UID_ESet: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post(UID_ESet: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_ESet_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_delete(UID_ITShopOrg: string, UID_ESet: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_admin_role_eset_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, risk: string, esettype: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_eset_put(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_eset_post(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_eset_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the admin/role/eset endpoint. */
    portal_admin_role_eset_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_admin_role_eset_interactive_get(requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_admin_role_eset_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_admin_role_eset_interactive_byid_get(UID_ESet: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_person_rolememberships_ESet_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resp_eset_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, esettype: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/eset endpoint. */
    portal_resp_eset_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_eset_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_eset_interactive_byid_get(UID_ESet: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_roles_config_classes_ESet_get(requestOptions?: ApiRequestOptions): Promise<RoleAssignmentData[]>;
    portal_roles_config_entitlements_ESet_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_post(UID_ESet: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_delete(UID_ESet: string, UID_ESetHasEntitlement: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/ESet/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERResource/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_roles_config_membership_ESet_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_membership_ESet_post(UID_ESet: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_membership_ESet_delete(UID_ESet: string, UID_Person: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_ESet_UID_Person_candidates_get(UID_ESet: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/membership/ESet/{UID_ESet}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post(UID_ESet: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_shop_config_entitlements_ESet_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_delete(UID_ITShopOrg: string, UID_ESet: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_ESet. */
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/ESet/UID_ESet/candidates endpoint. */
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
}
export interface portal_admin_role_eset_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filter by risk index */ risk?: string;
    /** System role type */ esettype?: string;
}
export interface portal_admin_role_eset_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_person_rolememberships_ESet_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_resp_eset_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** System role type */ esettype?: string;
}
export interface portal_resp_eset_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_roles_config_entitlements_ESet_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_roles_config_membership_ESet_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_roles_config_membership_ESet_UID_Person_candidates_get_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_shop_config_entitlements_ESet_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_ESet_UID_ESet_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export declare class V2ApiClientMethodFactory {
    portal_admin_role_eset_get(options?: portal_admin_role_eset_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_eset_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_eset_post(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_eset_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_admin_role_eset_datamodel_get(options?: portal_admin_role_eset_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_admin_role_eset_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_eset_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_eset_interactive_byid_get(/** Primary key value UID_ESet */ UID_ESet: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_person_rolememberships_ESet_get(/** Unique identity identifier */ UID_Person: string, options?: portal_person_rolememberships_ESet_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_eset_get(options?: portal_resp_eset_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_eset_datamodel_get(options?: portal_resp_eset_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_resp_eset_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resp_eset_interactive_byid_get(/** Primary key value UID_ESet */ UID_ESet: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_roles_config_classes_ESet_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<RoleAssignmentData[]>;
    portal_roles_config_entitlements_ESet_get(/** Unique identifier of the system role */ UID_ESet: string, options?: portal_roles_config_entitlements_ESet_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_post(/** Unique identifier of the system role */ UID_ESet: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_delete(/** Unique identifier of the system role */ UID_ESet: string, /** System role assignment */ UID_ESetHasEntitlement: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get(/** Unique identifier of the system role */ UID_ESet: string, options?: portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post(/** Unique identifier of the system role */ UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get(/** Unique identifier of the system role */ UID_ESet: string, options?: portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post(/** Unique identifier of the system role */ UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_roles_config_membership_ESet_get(/** Unique identifier of the system role */ UID_ESet: string, options?: portal_roles_config_membership_ESet_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_post(/** Unique identifier of the system role */ UID_ESet: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_delete(/** Unique identifier of the system role */ UID_ESet: string, /** Identity */ UID_Person: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_UID_Person_candidates_get(/** Unique identifier of the system role */ UID_ESet: string, options?: portal_roles_config_membership_ESet_UID_Person_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post(/** Unique identifier of the system role */ UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_ESet_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_ESet_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** System roles */ UID_ESet: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_ESet_UID_ESet_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_admin_role_eset_get(options?: portal_admin_role_eset_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_eset_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_eset_post(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_eset_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the admin/role/eset endpoint. */
    portal_admin_role_eset_datamodel_get(options?: portal_admin_role_eset_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_admin_role_eset_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_admin_role_eset_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_admin_role_eset_interactive_byid_get(/** Primary key value UID_ESet */ UID_ESet: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_person_rolememberships_ESet_get(/** Unique identity identifier */ UID_Person: string, options?: portal_person_rolememberships_ESet_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resp_eset_get(options?: portal_resp_eset_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/eset endpoint. */
    portal_resp_eset_datamodel_get(options?: portal_resp_eset_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_eset_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_eset_interactive_byid_get(/** Primary key value UID_ESet */ UID_ESet: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_roles_config_classes_ESet_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<RoleAssignmentData[]>;
    portal_roles_config_entitlements_ESet_get(/** Unique identifier of the system role */ UID_ESet: string, options?: portal_roles_config_entitlements_ESet_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_post(/** Unique identifier of the system role */ UID_ESet: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_delete(/** Unique identifier of the system role */ UID_ESet: string, /** System role assignment */ UID_ESetHasEntitlement: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get(/** Unique identifier of the system role */ UID_ESet: string, options?: portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/ESet/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post(/** Unique identifier of the system role */ UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get(/** Unique identifier of the system role */ UID_ESet: string, options?: portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERResource/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post(/** Unique identifier of the system role */ UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_roles_config_membership_ESet_get(/** Unique identifier of the system role */ UID_ESet: string, options?: portal_roles_config_membership_ESet_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_membership_ESet_post(/** Unique identifier of the system role */ UID_ESet: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_membership_ESet_delete(/** Unique identifier of the system role */ UID_ESet: string, /** Identity */ UID_Person: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_ESet_UID_Person_candidates_get(/** Unique identifier of the system role */ UID_ESet: string, options?: portal_roles_config_membership_ESet_UID_Person_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/membership/ESet/{UID_ESet}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post(/** Unique identifier of the system role */ UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_shop_config_entitlements_ESet_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_ESet_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** System roles */ UID_ESet: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_ESet. */
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_ESet_UID_ESet_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/ESet/UID_ESet/candidates endpoint. */
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
}
