import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, ExtendedEntityWriteData, FilterData, FilterTreeData, FkProviderItem, InteractiveEntityData, InteractiveEntityWriteData, IReadValue, MethodDescriptor, StaticSchema, TypedEntity, WriteExtTypedEntity } from 'imx-qbm-dbts';
export interface ByAbilityResult {
    Data?: SAPUserFunctionSrcFLD[];
}
export interface ByRoleResult {
    Elements?: ByRoleResultElement[];
}
export interface ByRoleResultElement {
    GroupName?: string;
    Description?: string;
    GroupFlag?: number;
    GroupType?: string;
    ChildElements?: ByRoleResultElement[];
    Prof?: SAPUserFunctionSrcPROF[];
}
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityWriteDataOfGroupExtendedData extends EntityWriteData {
    ExtendedData?: GroupExtendedData;
}
export interface ExtendedInteractiveEntityWriteDataOfGroupExtendedData extends InteractiveEntityWriteData {
    ExtendedData?: GroupExtendedData;
}
export interface GroupExtendedData {
    CreateServiceItem: boolean;
}
export interface SAPUserFunctionSrcFLD {
    Ident_SAPProfile?: string;
    Ident_SAPAuthObject?: string;
    TransactionCode?: string;
    Ident_SAPField?: string;
    LowerLimit?: string;
    UpperLimit?: string;
    UID_SAPGroup?: string;
    UID_SAPFunctionInstance?: string;
    DisplaySapFunctionInstance?: string;
    DisplaySapTransaction?: string;
}
export interface SAPUserFunctionSrcPROF {
    Ident_SAPProfile?: string;
    Objects?: string;
    Field?: string;
    LowerLimit?: string;
    UpperLimit?: string;
    UID_SAPGroup?: string;
}
export declare class TypedClient {
    readonly PortalSapgrpMemberships: PortalSapgrpMembershipsWrapper;
    readonly PortalSapprofileMemberships: PortalSapprofileMembershipsWrapper;
    readonly PortalSaproleMemberships: PortalSaproleMembershipsWrapper;
    readonly PortalTargetsystemSapgrp: PortalTargetsystemSapgrpWrapper;
    readonly PortalTargetsystemSapgrpInteractive: PortalTargetsystemSapgrpInteractiveWrapper;
    readonly PortalTargetsystemSapprofile: PortalTargetsystemSapprofileWrapper;
    readonly PortalTargetsystemSapprofileInteractive: PortalTargetsystemSapprofileInteractiveWrapper;
    readonly PortalTargetsystemSaprole: PortalTargetsystemSaproleWrapper;
    readonly PortalTargetsystemSaproleInteractive: PortalTargetsystemSaproleInteractiveWrapper;
    readonly PortalTargetsystemSapuser: PortalTargetsystemSapuserWrapper;
    readonly PortalTargetsystemSapuserInteractive: PortalTargetsystemSapuserInteractiveWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalSapgrpMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalSapgrpMemberships type. */
export declare class PortalSapgrpMembershipsInteractive extends PortalSapgrpMemberships {
}
export declare class PortalSapprofileMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalSapprofileMemberships type. */
export declare class PortalSapprofileMembershipsInteractive extends PortalSapprofileMemberships {
}
export declare class PortalSaproleMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalSaproleMemberships type. */
export declare class PortalSaproleMembershipsInteractive extends PortalSaproleMemberships {
}
export declare class PortalTargetsystemSapgrp extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemSapgrp type. */
export declare class PortalTargetsystemSapgrpInteractive extends PortalTargetsystemSapgrp {
}
export declare class PortalTargetsystemSapprofile extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemSapprofile type. */
export declare class PortalTargetsystemSapprofileInteractive extends PortalTargetsystemSapprofile {
}
export declare class PortalTargetsystemSaprole extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemSaprole type. */
export declare class PortalTargetsystemSaproleInteractive extends PortalTargetsystemSaprole {
}
export declare class PortalTargetsystemSapuser extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalTargetsystemSapuser type. */
export declare class PortalTargetsystemSapuserInteractive extends PortalTargetsystemSapuser {
}
export declare class PortalSapgrpMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSapgrpMemberships, unknown>>;
}
export declare class PortalSapprofileMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSapprofileMemberships, unknown>>;
}
export declare class PortalSaproleMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSaproleMemberships, unknown>>;
}
export declare class PortalTargetsystemSapgrpWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_sapgrp_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSapgrp, unknown>>;
    Put(inputParameterName: PortalTargetsystemSapgrp, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSapgrp, unknown>>;
}
export declare class PortalTargetsystemSapgrpInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemSapgrp, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSapgrp, unknown>>;
    Get_byid(UID_SAPGrp: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSapgrp, unknown>>;
}
export declare class PortalTargetsystemSapprofileWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_sapprofile_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSapprofile, unknown>>;
    Put(inputParameterName: PortalTargetsystemSapprofile, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSapprofile, unknown>>;
}
export declare class PortalTargetsystemSapprofileInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemSapprofile, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSapprofile, unknown>>;
    Get_byid(UID_SAPProfile: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSapprofile, unknown>>;
}
export declare class PortalTargetsystemSaproleWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_saprole_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSaprole, unknown>>;
    Put(inputParameterName: PortalTargetsystemSaprole, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSaprole, unknown>>;
}
export declare class PortalTargetsystemSaproleInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemSaprole, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSaprole, unknown>>;
    Get_byid(UID_SAPRole: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSaprole, unknown>>;
}
export declare class PortalTargetsystemSapuserWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_sapuser_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSapuser, unknown>>;
    Put(inputParameterName: PortalTargetsystemSapuser, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSapuser, unknown>>;
}
export declare class PortalTargetsystemSapuserInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemSapuser, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSapuser, unknown>>;
    Get_byid(UID_SAPUser: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemSapuser, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_sap_ruleanalysis_byrole_get(uidsapuser: string, uidcompliancerule: string): MethodDescriptor<ByRoleResult>;
    portal_sap_ruleanalysis_fld_get(uidsapuser: string, uidcompliancerule: string): MethodDescriptor<ByAbilityResult>;
    portal_sap_ruleanalysis_prof_get(uidsapuser: string, uidcompliancerule: string): MethodDescriptor<SAPUserFunctionSrcPROF[]>;
    portal_SAPGrp_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_SAPGrp_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_SAPProfile_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_SAPProfile_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_SAPRole_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_SAPRole_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_sapgrp_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_sapgrp_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_sapgrp_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_sapgrp_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_sapgrp_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_sapgrp_interactive_byid_get(UID_SAPGrp: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_sapprofile_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_sapprofile_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_sapprofile_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_sapprofile_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_sapprofile_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_sapprofile_interactive_byid_get(UID_SAPProfile: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_saprole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_saprole_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_saprole_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_saprole_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_saprole_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_saprole_interactive_byid_get(UID_SAPRole: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_sapuser_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_sapuser_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_sapuser_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_sapuser_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_sapuser_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_sapuser_interactive_byid_get(UID_SAPUser: string): MethodDescriptor<InteractiveEntityData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_sap_ruleanalysis_byrole_get(uidsapuser: string, uidcompliancerule: string, requestOptions?: ApiRequestOptions): Promise<ByRoleResult>;
    portal_sap_ruleanalysis_fld_get(uidsapuser: string, uidcompliancerule: string, requestOptions?: ApiRequestOptions): Promise<ByAbilityResult>;
    portal_sap_ruleanalysis_prof_get(uidsapuser: string, uidcompliancerule: string, requestOptions?: ApiRequestOptions): Promise<SAPUserFunctionSrcPROF[]>;
    portal_SAPGrp_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_SAPGrp_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_SAPProfile_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_SAPProfile_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_SAPRole_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_SAPRole_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_SAPGrp. */
    portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates endpoint. */
    portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates endpoint. */
    portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_SAPProfile. */
    portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates endpoint. */
    portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates endpoint. */
    portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_SAPRole. */
    portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates endpoint. */
    portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates endpoint. */
    portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_sapgrp_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_sapgrp_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_sapgrp_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/sapgrp endpoint. */
    portal_targetsystem_sapgrp_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_sapgrp_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_sapgrp_interactive_byid_get(UID_SAPGrp: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_sapprofile_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_sapprofile_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_sapprofile_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/sapprofile endpoint. */
    portal_targetsystem_sapprofile_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_sapprofile_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_sapprofile_interactive_byid_get(UID_SAPProfile: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_saprole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_saprole_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_saprole_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/saprole endpoint. */
    portal_targetsystem_saprole_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_saprole_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_saprole_interactive_byid_get(UID_SAPRole: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_sapuser_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_sapuser_put(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_sapuser_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/sapuser endpoint. */
    portal_targetsystem_sapuser_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_sapuser_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_sapuser_interactive_byid_get(UID_SAPUser: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
}
export interface portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_sapgrp_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_sapgrp_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_sapprofile_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_sapprofile_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_saprole_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_saprole_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_sapuser_get_args {
    /** Filters accounts for main and sub identities associated with the specified identity */ UID_PersonAssociated?: string;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters orphaned accounts */ orphaned?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_sapuser_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export declare class V2ApiClientMethodFactory {
    portal_sap_ruleanalysis_byrole_get(uidsapuser: string, uidcompliancerule: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ByRoleResult>;
    portal_sap_ruleanalysis_fld_get(uidsapuser: string, uidcompliancerule: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ByAbilityResult>;
    portal_sap_ruleanalysis_prof_get(uidsapuser: string, uidcompliancerule: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<SAPUserFunctionSrcPROF[]>;
    portal_SAPGrp_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_SAPGrp_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_SAPProfile_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_SAPProfile_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_SAPRole_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_SAPRole_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_sapgrp_get(options?: portal_targetsystem_sapgrp_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_sapgrp_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_sapgrp_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_sapgrp_datamodel_get(options?: portal_targetsystem_sapgrp_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_sapgrp_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_sapgrp_interactive_byid_get(/** Primary key value UID_SAPGrp */ UID_SAPGrp: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_sapprofile_get(options?: portal_targetsystem_sapprofile_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_sapprofile_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_sapprofile_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_sapprofile_datamodel_get(options?: portal_targetsystem_sapprofile_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_sapprofile_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_sapprofile_interactive_byid_get(/** Primary key value UID_SAPProfile */ UID_SAPProfile: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_saprole_get(options?: portal_targetsystem_saprole_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_saprole_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_saprole_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_saprole_datamodel_get(options?: portal_targetsystem_saprole_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_saprole_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_saprole_interactive_byid_get(/** Primary key value UID_SAPRole */ UID_SAPRole: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_sapuser_get(options?: portal_targetsystem_sapuser_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_sapuser_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_sapuser_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_sapuser_datamodel_get(options?: portal_targetsystem_sapuser_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_sapuser_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_sapuser_interactive_byid_get(/** Primary key value UID_SAPUser */ UID_SAPUser: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_sap_ruleanalysis_byrole_get(uidsapuser: string, uidcompliancerule: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ByRoleResult>;
    portal_sap_ruleanalysis_fld_get(uidsapuser: string, uidcompliancerule: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ByAbilityResult>;
    portal_sap_ruleanalysis_prof_get(uidsapuser: string, uidcompliancerule: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<SAPUserFunctionSrcPROF[]>;
    portal_SAPGrp_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_SAPGrp_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_SAPProfile_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_SAPProfile_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_SAPRole_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_SAPRole_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_SAPGrp. */
    portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates endpoint. */
    portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates endpoint. */
    portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_SAPProfile. */
    portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates endpoint. */
    portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates endpoint. */
    portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_SAPRole. */
    portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates endpoint. */
    portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates endpoint. */
    portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_sapgrp_get(options?: portal_targetsystem_sapgrp_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_sapgrp_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_sapgrp_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/sapgrp endpoint. */
    portal_targetsystem_sapgrp_datamodel_get(options?: portal_targetsystem_sapgrp_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_sapgrp_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_sapgrp_interactive_byid_get(/** Primary key value UID_SAPGrp */ UID_SAPGrp: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_sapprofile_get(options?: portal_targetsystem_sapprofile_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_sapprofile_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_sapprofile_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/sapprofile endpoint. */
    portal_targetsystem_sapprofile_datamodel_get(options?: portal_targetsystem_sapprofile_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_sapprofile_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_sapprofile_interactive_byid_get(/** Primary key value UID_SAPProfile */ UID_SAPProfile: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_saprole_get(options?: portal_targetsystem_saprole_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_saprole_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_saprole_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/saprole endpoint. */
    portal_targetsystem_saprole_datamodel_get(options?: portal_targetsystem_saprole_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_saprole_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_saprole_interactive_byid_get(/** Primary key value UID_SAPRole */ UID_SAPRole: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_sapuser_get(options?: portal_targetsystem_sapuser_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_sapuser_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_sapuser_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/sapuser endpoint. */
    portal_targetsystem_sapuser_datamodel_get(options?: portal_targetsystem_sapuser_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_sapuser_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_sapuser_interactive_byid_get(/** Primary key value UID_SAPUser */ UID_SAPUser: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
}
