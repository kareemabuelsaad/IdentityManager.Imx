import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntityKeysData, EntitySchema, EntityWriteData, EntityWriteDataSingle, ExtendedEntityCollectionData, FilterData, FilterTreeData, FkProviderItem, GroupInfoData, InteractiveEntityData, InteractiveEntityDeleteData, InteractiveEntityStateData, InteractiveEntityWriteData, IReadValue, IWriteValue, MethodDescriptor, ReadExtTypedEntity, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
export interface ActionInput extends ResolveInput {
    ReasonText?: string;
    ActionIds?: string[];
}
export interface ComplianceFeatureConfig {
    /** Returns a flag indicating whether mitigating controls are managed and assigned per rule violation
(true) or per compliance rule (false). */
    MitigatingControlsPerViolation: boolean;
}
export interface ComplianceViolation {
    ViolationType?: string;
    UidShoppingCartItem?: string;
    UidPerson?: string;
    DisplayPerson?: string;
    UidPersonWantsOrg?: string;
    ObjectKeyElement?: string;
    DisplayElement?: string;
    UidComplianceRule?: string;
    DisplayRule?: string;
    Description?: string;
    RuleNumber?: string;
    RiskIndex: number;
    RiskIndexReduced: number;
    UidComplianceSubRule?: string;
    UidNonCompliance?: string;
    IsNoEffectivePerson: boolean;
    Sources?: ContributingEntitlement[];
    ContributingEntitlements?: ContributingEntitlement[];
    IsExceptionApprover: boolean;
}
export interface ContributingEntitlement {
    ObjectKeyEntitlement?: string;
    Display?: string;
    Sources?: ContributingEntitlement[];
}
export interface DeferredOperationData {
    /** Returns the list of mitigating controls that will be assigned to this rule violation
when the request is granted. */
    MitigatingControls?: DeferredOperationMControlData[];
}
export interface DeferredOperationMControlData {
    Display?: string;
    Uid?: string;
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityCollectionDataOfDeferredOperationData extends EntityCollectionData {
    ExtendedData?: DeferredOperationData;
}
export interface ExtendedInteractiveEntityDataOfDeferredOperationData extends InteractiveEntityData {
    ExtendedData?: DeferredOperationData;
}
export interface NonComplianceDecisionInput {
    ExceptionValidUntil?: Date;
    Reason?: string;
    UidJustification?: string;
    Decision: boolean;
}
export interface ResolveInput {
    ObjectKeys?: string[];
}
export interface RoleComplianceViolation {
    UID_ComplianceRule?: string;
    RuleName?: string;
    DbObjectKey?: string;
    ObjectDisplay?: string;
    ObjectKeyElement?: string;
}
export interface RoleComplianceViolations {
    Violations?: RoleComplianceViolation[];
}
export interface UiActionData {
    Id?: string;
    IsActive: boolean;
    CanExecute: boolean;
    Display?: string;
    ObjectDisplay?: string;
}
export declare class TypedClient {
    readonly PortalCandidatesMitigatingcontrol: PortalCandidatesMitigatingcontrolWrapper;
    readonly PortalPersonMitigatingcontrols: PortalPersonMitigatingcontrolsWrapper;
    readonly PortalPersonMitigatingcontrolsInteractive: PortalPersonMitigatingcontrolsInteractiveWrapper;
    readonly PortalPersonRolemembershipsNoncompliance: PortalPersonRolemembershipsNoncomplianceWrapper;
    readonly PortalRules: PortalRulesWrapper;
    readonly PortalRulesMitigatingcontrols: PortalRulesMitigatingcontrolsWrapper;
    readonly PortalRulesViolations: PortalRulesViolationsWrapper;
    readonly PortalRulesWorkingcopiesMitigatingcontrols: PortalRulesWorkingcopiesMitigatingcontrolsWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalCandidatesMitigatingcontrol extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_MitigatingControl: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_MitigatingControl'>;
}
/** @deprecated Use the PortalCandidatesMitigatingcontrol type. */
export declare class PortalCandidatesMitigatingcontrolInteractive extends PortalCandidatesMitigatingcontrol {
}
export declare class PortalPersonMitigatingcontrols extends ReadExtTypedEntity<DeferredOperationData> {
    readonly UID_MitigatingControl: IWriteValue<string>;
    readonly IsInActive: IReadValue<boolean>;
    readonly UID_PersonWantsOrg: IWriteValue<string>;
    readonly UID_PersonInNCHasMControl: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly UID_NonCompliance: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_MitigatingControl' | 'IsInActive' | 'UID_PersonWantsOrg' | 'UID_PersonInNCHasMControl' | 'UID_Person' | 'UID_NonCompliance'>;
}
/** @deprecated Use the PortalPersonMitigatingcontrols type. */
export declare class PortalPersonMitigatingcontrolsInteractive extends PortalPersonMitigatingcontrols {
}
export declare class PortalPersonRolemembershipsNoncompliance extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_NonCompliance: IReadValue<string>;
    readonly ExceptionValidUntil: IReadValue<Date>;
    readonly IsDecisionMade: IReadValue<boolean>;
    readonly IsExceptionGranted: IReadValue<boolean>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly RiskIndexReduced: IReadValue<number>;
    readonly DecisionDate: IReadValue<Date>;
    readonly DecisionReason: IReadValue<string>;
    readonly RoleFullPath: IReadValue<string>;
    readonly HasMitigation: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'UID_NonCompliance' | 'ExceptionValidUntil' | 'IsDecisionMade' | 'IsExceptionGranted' | 'RiskIndexCalculated' | 'RiskIndexReduced' | 'DecisionDate' | 'DecisionReason' | 'RoleFullPath' | 'HasMitigation'>;
}
/** @deprecated Use the PortalPersonRolemembershipsNoncompliance type. */
export declare class PortalPersonRolemembershipsNoncomplianceInteractive extends PortalPersonRolemembershipsNoncompliance {
}
export declare class PortalRules extends TypedEntity {
    readonly RuleSeverity: IReadValue<number>;
    readonly isToGrantEver: IReadValue<boolean>;
    readonly IsExceptionAllowed: IReadValue<boolean>;
    readonly IsInActive: IReadValue<boolean>;
    readonly IsWorkingCopy: IReadValue<boolean>;
    readonly Ident_ComplianceRule: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly RuleNumber: IReadValue<string>;
    readonly RiskIndex: IReadValue<number>;
    readonly RiskIndexReduced: IReadValue<number>;
    readonly UID_NonCompliance: IReadValue<string>;
    readonly CountOpen: IReadValue<number>;
    readonly CountClosed: IReadValue<number>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'RuleSeverity' | 'isToGrantEver' | 'IsExceptionAllowed' | 'IsInActive' | 'IsWorkingCopy' | 'Ident_ComplianceRule' | 'Description' | 'RuleNumber' | 'RiskIndex' | 'RiskIndexReduced' | 'UID_NonCompliance' | 'CountOpen' | 'CountClosed'>;
}
/** @deprecated Use the PortalRules type. */
export declare class PortalRulesInteractive extends PortalRules {
}
export declare class PortalRulesMitigatingcontrols extends TypedEntity {
    readonly UID_ComplianceRule: IReadValue<string>;
    readonly UID_MitigatingControl: IReadValue<string>;
    readonly UID_NonCompliance: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ComplianceRule' | 'UID_MitigatingControl' | 'UID_NonCompliance'>;
}
/** @deprecated Use the PortalRulesMitigatingcontrols type. */
export declare class PortalRulesMitigatingcontrolsInteractive extends PortalRulesMitigatingcontrols {
}
export declare class PortalRulesViolations extends TypedEntity {
    readonly DecisionDate: IReadValue<Date>;
    readonly DecisionReason: IReadValue<string>;
    readonly ExceptionValidUntil: IReadValue<Date>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly RiskIndexReduced: IReadValue<number>;
    readonly UID_NonCompliance: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly UID_PersonDecisionMade: IReadValue<string>;
    readonly UID_QERJustification: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly State: IReadValue<string>;
    readonly HasMitigation: IReadValue<boolean>;
    readonly CanUserDecide: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'DecisionDate' | 'DecisionReason' | 'ExceptionValidUntil' | 'RiskIndexCalculated' | 'RiskIndexReduced' | 'UID_NonCompliance' | 'UID_Person' | 'UID_PersonDecisionMade' | 'UID_QERJustification' | 'XObjectKey' | 'State' | 'HasMitigation' | 'CanUserDecide'>;
}
/** @deprecated Use the PortalRulesViolations type. */
export declare class PortalRulesViolationsInteractive extends PortalRulesViolations {
}
export declare class PortalRulesWorkingcopiesMitigatingcontrols extends TypedEntity {
    readonly UID_ComplianceRule: IReadValue<string>;
    readonly UID_MitigatingControl: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ComplianceRule' | 'UID_MitigatingControl'>;
}
/** @deprecated Use the PortalRulesWorkingcopiesMitigatingcontrols type. */
export declare class PortalRulesWorkingcopiesMitigatingcontrolsInteractive extends PortalRulesWorkingcopiesMitigatingcontrols {
}
export declare class PortalCandidatesMitigatingcontrolWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_MitigatingControl_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesMitigatingcontrol, unknown>>;
}
export declare class PortalPersonMitigatingcontrolsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalPersonMitigatingcontrols;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Person: string, UID_NonCompliance: string, parametersOptional?: portal_person_mitigatingcontrols_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonMitigatingcontrols, DeferredOperationData>>;
    Post(UID_Person: string, UID_NonCompliance: string, inputParameterName: PortalPersonMitigatingcontrols, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonMitigatingcontrols, DeferredOperationData>>;
    Delete(UID_Person: string, UID_NonCompliance: string, UID_PersonInNCHasMControl: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonMitigatingcontrols, DeferredOperationData>>;
}
export declare class PortalPersonMitigatingcontrolsInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(UID_Person: string, UID_NonCompliance: string, inputParameterName: PortalPersonMitigatingcontrols, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonMitigatingcontrols, DeferredOperationData>>;
    Delete(UID_Person: string, UID_NonCompliance: string, inputParameterName: PortalPersonMitigatingcontrols, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonMitigatingcontrols, DeferredOperationData>>;
    Get_byid(UID_Person: string, UID_NonCompliance: string, UID_PersonInNCHasMControl: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonMitigatingcontrols, DeferredOperationData>>;
    Get(UID_Person: string, UID_NonCompliance: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonMitigatingcontrols, DeferredOperationData>>;
}
export declare class PortalPersonRolemembershipsNoncomplianceWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Person: string, parametersOptional?: portal_person_rolememberships_NonCompliance_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonRolemembershipsNoncompliance, unknown>>;
}
export declare class PortalRulesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_rules_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRules, unknown>>;
}
export declare class PortalRulesMitigatingcontrolsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_NonCompliance: string, parametersOptional?: portal_rules_mitigatingcontrols_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRulesMitigatingcontrols, unknown>>;
}
export declare class PortalRulesViolationsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_rules_violations_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRulesViolations, unknown>>;
}
export declare class PortalRulesWorkingcopiesMitigatingcontrolsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalRulesWorkingcopiesMitigatingcontrols;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ComplianceRule: string, parametersOptional?: portal_rules_workingcopies_mitigatingcontrols_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRulesWorkingcopiesMitigatingcontrols, unknown>>;
    Post(UID_ComplianceRule: string, inputParameterName: PortalRulesWorkingcopiesMitigatingcontrols, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRulesWorkingcopiesMitigatingcontrols, unknown>>;
    Delete(UID_ComplianceRule: string, UID_MitigatingControl: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRulesWorkingcopiesMitigatingcontrols, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_candidates_MitigatingControl_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_MitigatingControl_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_compliance_config_get(): MethodDescriptor<ComplianceFeatureConfig>;
    portal_itshop_requests_compliance_get(uid_personwantsorg: string): MethodDescriptor<ComplianceViolation[]>;
    portal_person_mitigatingcontrols_get(UID_Person: string, UID_NonCompliance: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<ExtendedEntityCollectionData<DeferredOperationData>>;
    portal_person_mitigatingcontrols_post(UID_Person: string, UID_NonCompliance: string, inputParameterName: EntityWriteData): MethodDescriptor<ExtendedEntityCollectionData<DeferredOperationData>>;
    portal_person_mitigatingcontrols_delete(UID_Person: string, UID_NonCompliance: string, UID_PersonInNCHasMControl: string): MethodDescriptor<ExtendedEntityCollectionData<DeferredOperationData>>;
    portal_person_mitigatingcontrols_interactive_get(UID_Person: string, UID_NonCompliance: string): MethodDescriptor<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    portal_person_mitigatingcontrols_interactive_put(UID_Person: string, UID_NonCompliance: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    portal_person_mitigatingcontrols_interactive_delete(UID_Person: string, UID_NonCompliance: string, inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    portal_person_mitigatingcontrols_interactive_forrequest_get(UID_Person: string, UID_NonCompliance: string, entityid: string, keys: string[], state: string): MethodDescriptor<boolean>;
    portal_person_mitigatingcontrols_interactive_byid_get(UID_Person: string, UID_NonCompliance: string, UID_PersonInNCHasMControl: string): MethodDescriptor<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_post(UID_Person: string, UID_NonCompliance: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: InteractiveEntityStateData): MethodDescriptor<EntityCollectionData>;
    portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_filtertree_post(UID_Person: string, UID_NonCompliance: string, filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post(UID_Person: string, UID_NonCompliance: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: EntityKeysData): MethodDescriptor<EntityCollectionData>;
    portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_filtertree_post(UID_Person: string, UID_NonCompliance: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_person_rolememberships_NonCompliance_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_compliance_get(roleTable: string, rolePk: string): MethodDescriptor<RoleComplianceViolations>;
    portal_rules_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, active: string): MethodDescriptor<EntityCollectionData>;
    portal_rules_mitigatingcontrols_get(UID_NonCompliance: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_rules_recalculate_post(uid: string): MethodDescriptor<void>;
    portal_rules_report_get(uidrule: string): MethodDescriptor<void>;
    portal_rules_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_rules_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, active: string): MethodDescriptor<GroupInfoData>;
    portal_rules_violations_get(approvable: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, uid_compliancerule: string): MethodDescriptor<EntityCollectionData>;
    portal_rules_violations_post(uidperson: string, uidnoncompliance: string, inputParameterName: NonComplianceDecisionInput): MethodDescriptor<void>;
    portal_rules_violations_actions_post(uidperson: string, uidnoncompliance: string, inputParameterName: ResolveInput): MethodDescriptor<UiActionData[]>;
    portal_rules_violations_analyzeloss_post(uidperson: string, uidnoncompliance: string, inputParameterName: ActionInput): MethodDescriptor<ContributingEntitlement[]>;
    portal_rules_violations_entitlements_get(uidperson: string, uidnoncompliance: string): MethodDescriptor<ContributingEntitlement[]>;
    portal_rules_violations_result_post(uidperson: string, uidnoncompliance: string, inputParameterName: ActionInput): MethodDescriptor<void>;
    portal_rules_violations_datamodel_get(approvable: boolean, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_rules_violations_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, state: string, uid_compliancerule: string, approvable: boolean): MethodDescriptor<GroupInfoData>;
    portal_rules_workingcopies_mitigatingcontrols_get(UID_ComplianceRule: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_rules_workingcopies_mitigatingcontrols_post(UID_ComplianceRule: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_rules_workingcopies_mitigatingcontrols_delete(UID_ComplianceRule: string, UID_MitigatingControl: string): MethodDescriptor<EntityCollectionData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns a list of candidate objects from the table MitigatingControl. */
    portal_candidates_MitigatingControl_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/MitigatingControl endpoint. */
    portal_candidates_MitigatingControl_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_compliance_config_get(requestOptions?: ApiRequestOptions): Promise<ComplianceFeatureConfig>;
    /** Returns the compliance check result for the specified request. */
    portal_itshop_requests_compliance_get(uid_personwantsorg: string, requestOptions?: ApiRequestOptions): Promise<ComplianceViolation[]>;
    portal_person_mitigatingcontrols_get(UID_Person: string, UID_NonCompliance: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<DeferredOperationData>>;
    /** Assign a mitigating control to the rule violation. */
    portal_person_mitigatingcontrols_post(UID_Person: string, UID_NonCompliance: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<DeferredOperationData>>;
    /** Removes a mitigating control from the rule violation. */
    portal_person_mitigatingcontrols_delete(UID_Person: string, UID_NonCompliance: string, UID_PersonInNCHasMControl: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<DeferredOperationData>>;
    /** Assign a mitigating control to the rule violation. */
    portal_person_mitigatingcontrols_interactive_get(UID_Person: string, UID_NonCompliance: string, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    portal_person_mitigatingcontrols_interactive_put(UID_Person: string, UID_NonCompliance: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    /** Removes a mitigating control from the rule violation. */
    portal_person_mitigatingcontrols_interactive_delete(UID_Person: string, UID_NonCompliance: string, inputParameterName: InteractiveEntityDeleteData, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    /** Saves the mitigating control assignment for a specific request as a deferred operation. */
    portal_person_mitigatingcontrols_interactive_forrequest_get(UID_Person: string, UID_NonCompliance: string, entityid: string, keys: string[], state: string, requestOptions?: ApiRequestOptions): Promise<boolean>;
    portal_person_mitigatingcontrols_interactive_byid_get(UID_Person: string, UID_NonCompliance: string, UID_PersonInNCHasMControl: string, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    /** Returns a list of objects that can be assigned to the property UID_MitigatingControl. */
    portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_post(UID_Person: string, UID_NonCompliance: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: InteractiveEntityStateData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive/UID_MitigatingControl/candidates endpoint. */
    portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_filtertree_post(UID_Person: string, UID_NonCompliance: string, filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_MitigatingControl. */
    portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post(UID_Person: string, UID_NonCompliance: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: EntityKeysData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/UID_MitigatingControl/candidates endpoint. */
    portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_filtertree_post(UID_Person: string, UID_NonCompliance: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_person_rolememberships_NonCompliance_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_compliance_get(roleTable: string, rolePk: string, requestOptions?: ApiRequestOptions): Promise<RoleComplianceViolations>;
    portal_rules_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, active: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_rules_mitigatingcontrols_get(UID_NonCompliance: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Triggers a recalculation of the rule violations. */
    portal_rules_recalculate_post(uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_rules_report_get(uidrule: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the rules endpoint. */
    portal_rules_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_rules_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, active: string, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_rules_violations_get(approvable: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, uid_compliancerule: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_rules_violations_post(uidperson: string, uidnoncompliance: string, inputParameterName: NonComplianceDecisionInput, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_rules_violations_actions_post(uidperson: string, uidnoncompliance: string, inputParameterName: ResolveInput, requestOptions?: ApiRequestOptions): Promise<UiActionData[]>;
    portal_rules_violations_analyzeloss_post(uidperson: string, uidnoncompliance: string, inputParameterName: ActionInput, requestOptions?: ApiRequestOptions): Promise<ContributingEntitlement[]>;
    portal_rules_violations_entitlements_get(uidperson: string, uidnoncompliance: string, requestOptions?: ApiRequestOptions): Promise<ContributingEntitlement[]>;
    portal_rules_violations_result_post(uidperson: string, uidnoncompliance: string, inputParameterName: ActionInput, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the rules/violations endpoint. */
    portal_rules_violations_datamodel_get(approvable: boolean, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_rules_violations_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, state: string, uid_compliancerule: string, approvable: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_rules_workingcopies_mitigatingcontrols_get(UID_ComplianceRule: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Assign a mitigating control to the compliance rule. */
    portal_rules_workingcopies_mitigatingcontrols_post(UID_ComplianceRule: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Removes a mitigating control from the compliance rule. */
    portal_rules_workingcopies_mitigatingcontrols_delete(UID_ComplianceRule: string, UID_MitigatingControl: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
}
export interface portal_candidates_MitigatingControl_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_MitigatingControl_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_person_mitigatingcontrols_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_person_mitigatingcontrols_interactive_forrequest_get_args {
    keys?: string[];
    state?: string;
}
export interface portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_post_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_person_rolememberships_NonCompliance_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_rules_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filter by status */ active?: string;
}
export interface portal_rules_mitigatingcontrols_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_rules_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_rules_group_get_args {
    /** Comma-seperated list of columns */ by?: string;
    /** Pipe-seperated list of grouping definition data */ def?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Index of first group to return */ StartIndex?: number;
    /** Number of groups to return */ PageSize?: number;
    /** Includes count of items for each group */ withcount?: boolean;
    /** Filter by status */ active?: string;
}
export interface portal_rules_violations_get_args {
    /** Filters rule violations approvable by the current user */ approvable?: boolean;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filter by status */ state?: string;
    /** Filters by a specific compliance rule */ uid_compliancerule?: string;
}
export interface portal_rules_violations_datamodel_get_args {
    approvable?: boolean;
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_rules_violations_group_get_args {
    /** Comma-seperated list of columns */ by?: string;
    /** Pipe-seperated list of grouping definition data */ def?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Index of first group to return */ StartIndex?: number;
    /** Number of groups to return */ PageSize?: number;
    /** Includes count of items for each group */ withcount?: boolean;
    /** Filter by status */ state?: string;
    /** Filters by a specific compliance rule */ uid_compliancerule?: string;
    approvable?: boolean;
}
export interface portal_rules_workingcopies_mitigatingcontrols_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export declare class V2ApiClientMethodFactory {
    portal_candidates_MitigatingControl_get(options?: portal_candidates_MitigatingControl_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_MitigatingControl_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_MitigatingControl_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_compliance_config_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ComplianceFeatureConfig>;
    portal_itshop_requests_compliance_get(/** Unique request identifier */ uid_personwantsorg: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ComplianceViolation[]>;
    portal_person_mitigatingcontrols_get(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, options?: portal_person_mitigatingcontrols_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<DeferredOperationData>>;
    portal_person_mitigatingcontrols_post(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<DeferredOperationData>>;
    portal_person_mitigatingcontrols_delete(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, /** Mitigating control assignment */ UID_PersonInNCHasMControl: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<DeferredOperationData>>;
    portal_person_mitigatingcontrols_interactive_get(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    portal_person_mitigatingcontrols_interactive_put(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    portal_person_mitigatingcontrols_interactive_delete(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    portal_person_mitigatingcontrols_interactive_forrequest_get(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, entityid: string, options?: portal_person_mitigatingcontrols_interactive_forrequest_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<boolean>;
    portal_person_mitigatingcontrols_interactive_byid_get(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, /** Primary key value UID_PersonInNCHasMControl */ UID_PersonInNCHasMControl: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_post(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: InteractiveEntityStateData, options?: portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_filtertree_post(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: InteractiveEntityWriteData, options?: portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: EntityKeysData, options?: portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_filtertree_post(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: EntityWriteDataSingle, options?: portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_person_rolememberships_NonCompliance_get(/** Unique identity identifier */ UID_Person: string, options?: portal_person_rolememberships_NonCompliance_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_compliance_get(/** Type of the role */ roleTable: string, /** Unique identifier of the role */ rolePk: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<RoleComplianceViolations>;
    portal_rules_get(options?: portal_rules_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_rules_mitigatingcontrols_get(/** Unique rule violation identifier */ UID_NonCompliance: string, options?: portal_rules_mitigatingcontrols_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_rules_recalculate_post(/** Unique rule identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_rules_report_get(/** Unique rule identifier */ uidrule: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_rules_datamodel_get(options?: portal_rules_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_rules_group_get(options?: portal_rules_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfoData>;
    portal_rules_violations_get(options?: portal_rules_violations_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_rules_violations_post(/** Unique identity identifier */ uidperson: string, /** Unique non-compliance identifier */ uidnoncompliance: string, inputParameterName: NonComplianceDecisionInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_rules_violations_actions_post(/** Identifier of the identity with the rule violation */ uidperson: string, /** Identifier of the compliance violation node */ uidnoncompliance: string, inputParameterName: ResolveInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<UiActionData[]>;
    portal_rules_violations_analyzeloss_post(/** Identifier of the identity with the rule violation */ uidperson: string, /** Identifier of the compliance violation node */ uidnoncompliance: string, inputParameterName: ActionInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ContributingEntitlement[]>;
    portal_rules_violations_entitlements_get(/** Identifier of the identity with the rule violation */ uidperson: string, /** Identifier of the compliance violation node */ uidnoncompliance: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ContributingEntitlement[]>;
    portal_rules_violations_result_post(/** Identifier of the identity with the rule violation */ uidperson: string, /** Identifier of the compliance violation node */ uidnoncompliance: string, inputParameterName: ActionInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_rules_violations_datamodel_get(options?: portal_rules_violations_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_rules_violations_group_get(options?: portal_rules_violations_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfoData>;
    portal_rules_workingcopies_mitigatingcontrols_get(UID_ComplianceRule: string, options?: portal_rules_workingcopies_mitigatingcontrols_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_rules_workingcopies_mitigatingcontrols_post(UID_ComplianceRule: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_rules_workingcopies_mitigatingcontrols_delete(UID_ComplianceRule: string, /** Mitigating control */ UID_MitigatingControl: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns a list of candidate objects from the table MitigatingControl. */
    portal_candidates_MitigatingControl_get(options?: portal_candidates_MitigatingControl_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/MitigatingControl endpoint. */
    portal_candidates_MitigatingControl_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_MitigatingControl_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_compliance_config_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ComplianceFeatureConfig>;
    /** Returns the compliance check result for the specified request. */
    portal_itshop_requests_compliance_get(/** Unique request identifier */ uid_personwantsorg: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ComplianceViolation[]>;
    portal_person_mitigatingcontrols_get(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, options?: portal_person_mitigatingcontrols_get_args, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<DeferredOperationData>>;
    /** Assign a mitigating control to the rule violation. */
    portal_person_mitigatingcontrols_post(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<DeferredOperationData>>;
    /** Removes a mitigating control from the rule violation. */
    portal_person_mitigatingcontrols_delete(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, /** Mitigating control assignment */ UID_PersonInNCHasMControl: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<DeferredOperationData>>;
    /** Assign a mitigating control to the rule violation. */
    portal_person_mitigatingcontrols_interactive_get(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    portal_person_mitigatingcontrols_interactive_put(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    /** Removes a mitigating control from the rule violation. */
    portal_person_mitigatingcontrols_interactive_delete(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    /** Saves the mitigating control assignment for a specific request as a deferred operation. */
    portal_person_mitigatingcontrols_interactive_forrequest_get(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, entityid: string, options?: portal_person_mitigatingcontrols_interactive_forrequest_get_args, requestOptions?: ApiRequestOptions): Promise<boolean>;
    portal_person_mitigatingcontrols_interactive_byid_get(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, /** Primary key value UID_PersonInNCHasMControl */ UID_PersonInNCHasMControl: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfDeferredOperationData>;
    /** Returns a list of objects that can be assigned to the property UID_MitigatingControl. */
    portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_post(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: InteractiveEntityStateData, options?: portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_post_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive/UID_MitigatingControl/candidates endpoint. */
    portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_filtertree_post(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: InteractiveEntityWriteData, options?: portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_MitigatingControl. */
    portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: EntityKeysData, options?: portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/UID_MitigatingControl/candidates endpoint. */
    portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_filtertree_post(/** Unique identity identifier */ UID_Person: string, /** Unique rule violation identifier */ UID_NonCompliance: string, inputParameterName: EntityWriteDataSingle, options?: portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_person_rolememberships_NonCompliance_get(/** Unique identity identifier */ UID_Person: string, options?: portal_person_rolememberships_NonCompliance_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_compliance_get(/** Type of the role */ roleTable: string, /** Unique identifier of the role */ rolePk: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<RoleComplianceViolations>;
    portal_rules_get(options?: portal_rules_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_rules_mitigatingcontrols_get(/** Unique rule violation identifier */ UID_NonCompliance: string, options?: portal_rules_mitigatingcontrols_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Triggers a recalculation of the rule violations. */
    portal_rules_recalculate_post(/** Unique rule identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_rules_report_get(/** Unique rule identifier */ uidrule: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the rules endpoint. */
    portal_rules_datamodel_get(options?: portal_rules_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_rules_group_get(options?: portal_rules_group_get_args, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_rules_violations_get(options?: portal_rules_violations_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_rules_violations_post(/** Unique identity identifier */ uidperson: string, /** Unique non-compliance identifier */ uidnoncompliance: string, inputParameterName: NonComplianceDecisionInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_rules_violations_actions_post(/** Identifier of the identity with the rule violation */ uidperson: string, /** Identifier of the compliance violation node */ uidnoncompliance: string, inputParameterName: ResolveInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<UiActionData[]>;
    portal_rules_violations_analyzeloss_post(/** Identifier of the identity with the rule violation */ uidperson: string, /** Identifier of the compliance violation node */ uidnoncompliance: string, inputParameterName: ActionInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<ContributingEntitlement[]>;
    portal_rules_violations_entitlements_get(/** Identifier of the identity with the rule violation */ uidperson: string, /** Identifier of the compliance violation node */ uidnoncompliance: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ContributingEntitlement[]>;
    portal_rules_violations_result_post(/** Identifier of the identity with the rule violation */ uidperson: string, /** Identifier of the compliance violation node */ uidnoncompliance: string, inputParameterName: ActionInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the rules/violations endpoint. */
    portal_rules_violations_datamodel_get(options?: portal_rules_violations_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_rules_violations_group_get(options?: portal_rules_violations_group_get_args, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_rules_workingcopies_mitigatingcontrols_get(UID_ComplianceRule: string, options?: portal_rules_workingcopies_mitigatingcontrols_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Assign a mitigating control to the compliance rule. */
    portal_rules_workingcopies_mitigatingcontrols_post(UID_ComplianceRule: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Removes a mitigating control from the compliance rule. */
    portal_rules_workingcopies_mitigatingcontrols_delete(UID_ComplianceRule: string, /** Mitigating control */ UID_MitigatingControl: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
}
