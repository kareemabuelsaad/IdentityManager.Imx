import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, ExtendedEntityWriteData, FilterData, FilterTreeData, FkProviderItem, InteractiveEntityData, InteractiveEntityWriteData, IReadValue, IWriteValue, MethodDescriptor, StaticSchema, TypedEntity, WriteExtTypedEntity } from 'imx-qbm-dbts';
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityWriteDataOfGroupExtendedData extends EntityWriteData {
    ExtendedData?: GroupExtendedData;
}
export interface ExtendedInteractiveEntityWriteDataOfGroupExtendedData extends InteractiveEntityWriteData {
    ExtendedData?: GroupExtendedData;
}
export interface GroupExtendedData {
    CreateServiceItem: boolean;
}
export declare class TypedClient {
    readonly PortalO3edlMemberships: PortalO3edlMembershipsWrapper;
    readonly PortalO3eunifiedgroupMemberships: PortalO3eunifiedgroupMembershipsWrapper;
    readonly PortalTargetsystemO3edl: PortalTargetsystemO3edlWrapper;
    readonly PortalTargetsystemO3edlInteractive: PortalTargetsystemO3edlInteractiveWrapper;
    readonly PortalTargetsystemO3edlMailboxes: PortalTargetsystemO3edlMailboxesWrapper;
    readonly PortalTargetsystemO3emailbox: PortalTargetsystemO3emailboxWrapper;
    readonly PortalTargetsystemO3emailboxInteractive: PortalTargetsystemO3emailboxInteractiveWrapper;
    readonly PortalTargetsystemO3emailcontact: PortalTargetsystemO3emailcontactWrapper;
    readonly PortalTargetsystemO3emailcontactInteractive: PortalTargetsystemO3emailcontactInteractiveWrapper;
    readonly PortalTargetsystemO3emailuser: PortalTargetsystemO3emailuserWrapper;
    readonly PortalTargetsystemO3emailuserInteractive: PortalTargetsystemO3emailuserInteractiveWrapper;
    readonly PortalTargetsystemO3eunifiedgroup: PortalTargetsystemO3eunifiedgroupWrapper;
    readonly PortalTargetsystemO3eunifiedgroupInteractive: PortalTargetsystemO3eunifiedgroupInteractiveWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalO3edlMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalO3edlMemberships type. */
export declare class PortalO3edlMembershipsInteractive extends PortalO3edlMemberships {
}
export declare class PortalO3eunifiedgroupMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalO3eunifiedgroupMemberships type. */
export declare class PortalO3eunifiedgroupMembershipsInteractive extends PortalO3eunifiedgroupMemberships {
}
export declare class PortalTargetsystemO3edl extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemO3edl type. */
export declare class PortalTargetsystemO3edlInteractive extends PortalTargetsystemO3edl {
}
export declare class PortalTargetsystemO3edlMailboxes extends TypedEntity {
    readonly UID_O3EDL: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XOrigin: IReadValue<number>;
    readonly UID_O3EMailbox: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_O3EDL' | 'XObjectKey' | 'XMarkedForDeletion' | 'XDateInserted' | 'XOrigin' | 'UID_O3EMailbox'>;
}
/** @deprecated Use the PortalTargetsystemO3edlMailboxes type. */
export declare class PortalTargetsystemO3edlMailboxesInteractive extends PortalTargetsystemO3edlMailboxes {
}
export declare class PortalTargetsystemO3emailbox extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalTargetsystemO3emailbox type. */
export declare class PortalTargetsystemO3emailboxInteractive extends PortalTargetsystemO3emailbox {
}
export declare class PortalTargetsystemO3emailcontact extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalTargetsystemO3emailcontact type. */
export declare class PortalTargetsystemO3emailcontactInteractive extends PortalTargetsystemO3emailcontact {
}
export declare class PortalTargetsystemO3emailuser extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalTargetsystemO3emailuser type. */
export declare class PortalTargetsystemO3emailuserInteractive extends PortalTargetsystemO3emailuser {
}
export declare class PortalTargetsystemO3eunifiedgroup extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly IsMembershipDynamic: IReadValue<boolean>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'IsMembershipDynamic' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemO3eunifiedgroup type. */
export declare class PortalTargetsystemO3eunifiedgroupInteractive extends PortalTargetsystemO3eunifiedgroup {
}
export declare class PortalO3edlMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalO3edlMemberships, unknown>>;
}
export declare class PortalO3eunifiedgroupMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalO3eunifiedgroupMemberships, unknown>>;
}
export declare class PortalTargetsystemO3edlWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_o3edl_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3edl, unknown>>;
    Put(inputParameterName: PortalTargetsystemO3edl, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3edl, unknown>>;
}
export declare class PortalTargetsystemO3edlInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemO3edl, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3edl, unknown>>;
    Get_byid(UID_O3EDL: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3edl, unknown>>;
}
export declare class PortalTargetsystemO3edlMailboxesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalTargetsystemO3edlMailboxes;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_O3EDL: string, parametersOptional?: portal_targetsystem_o3edl_mailboxes_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3edlMailboxes, unknown>>;
    Post(UID_O3EDL: string, inputParameterName: PortalTargetsystemO3edlMailboxes, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3edlMailboxes, unknown>>;
    Delete(UID_O3EDL: string, UID_O3EMailbox: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3edlMailboxes, unknown>>;
}
export declare class PortalTargetsystemO3emailboxWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_o3emailbox_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3emailbox, unknown>>;
    Put(inputParameterName: PortalTargetsystemO3emailbox, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3emailbox, unknown>>;
}
export declare class PortalTargetsystemO3emailboxInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemO3emailbox, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3emailbox, unknown>>;
    Get_byid(UID_O3EMailbox: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3emailbox, unknown>>;
}
export declare class PortalTargetsystemO3emailcontactWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_o3emailcontact_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3emailcontact, unknown>>;
    Put(inputParameterName: PortalTargetsystemO3emailcontact, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3emailcontact, unknown>>;
}
export declare class PortalTargetsystemO3emailcontactInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemO3emailcontact, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3emailcontact, unknown>>;
    Get_byid(UID_O3EMailContact: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3emailcontact, unknown>>;
}
export declare class PortalTargetsystemO3emailuserWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_o3emailuser_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3emailuser, unknown>>;
    Put(inputParameterName: PortalTargetsystemO3emailuser, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3emailuser, unknown>>;
}
export declare class PortalTargetsystemO3emailuserInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemO3emailuser, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3emailuser, unknown>>;
    Get_byid(UID_O3EMailUser: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3emailuser, unknown>>;
}
export declare class PortalTargetsystemO3eunifiedgroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_o3eunifiedgroup_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3eunifiedgroup, unknown>>;
    Put(inputParameterName: PortalTargetsystemO3eunifiedgroup, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3eunifiedgroup, unknown>>;
}
export declare class PortalTargetsystemO3eunifiedgroupInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemO3eunifiedgroup, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3eunifiedgroup, unknown>>;
    Get_byid(UID_O3EUnifiedGroup: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemO3eunifiedgroup, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_O3EDL_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_O3EDL_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_O3EUnifiedGroup_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_O3EUnifiedGroup_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_o3edl_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3edl_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_get(UID_O3EDL: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_post(UID_O3EDL: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_delete(UID_O3EDL: string, UID_O3EMailbox: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_get(UID_O3EDL: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_datamodel_get(UID_O3EDL: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_filtertree_post(UID_O3EDL: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_o3edl_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_o3edl_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_o3edl_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3edl_interactive_byid_get(UID_O3EDL: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3emailbox_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3emailbox_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3emailbox_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_o3emailbox_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_o3emailbox_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3emailbox_interactive_byid_get(UID_O3EMailbox: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3emailcontact_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3emailcontact_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3emailcontact_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_o3emailcontact_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_o3emailcontact_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3emailcontact_interactive_byid_get(UID_O3EMailContact: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3emailuser_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3emailuser_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3emailuser_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_o3emailuser_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_o3emailuser_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3emailuser_interactive_byid_get(UID_O3EMailUser: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3eunifiedgroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3eunifiedgroup_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3eunifiedgroup_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_o3eunifiedgroup_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_o3eunifiedgroup_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3eunifiedgroup_interactive_byid_get(UID_O3EUnifiedGroup: string): MethodDescriptor<InteractiveEntityData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_O3EDL_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_O3EDL_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_O3EUnifiedGroup_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_O3EUnifiedGroup_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_O3EDL. */
    portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates endpoint. */
    portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates endpoint. */
    portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_O3EUnifiedGroup. */
    portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates endpoint. */
    portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates endpoint. */
    portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_o3edl_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3edl_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_get(UID_O3EDL: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_post(UID_O3EDL: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_delete(UID_O3EDL: string, UID_O3EMailbox: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_O3EMailbox. */
    portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_get(UID_O3EDL: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates endpoint. */
    portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_datamodel_get(UID_O3EDL: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates endpoint. */
    portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_filtertree_post(UID_O3EDL: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_o3edl_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/o3edl endpoint. */
    portal_targetsystem_o3edl_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_o3edl_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3edl_interactive_byid_get(UID_O3EDL: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3emailbox_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3emailbox_put(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3emailbox_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/o3emailbox endpoint. */
    portal_targetsystem_o3emailbox_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_o3emailbox_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3emailbox_interactive_byid_get(UID_O3EMailbox: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3emailcontact_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3emailcontact_put(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3emailcontact_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/o3emailcontact endpoint. */
    portal_targetsystem_o3emailcontact_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_o3emailcontact_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3emailcontact_interactive_byid_get(UID_O3EMailContact: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3emailuser_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3emailuser_put(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3emailuser_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/o3emailuser endpoint. */
    portal_targetsystem_o3emailuser_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_o3emailuser_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3emailuser_interactive_byid_get(UID_O3EMailUser: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3eunifiedgroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3eunifiedgroup_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3eunifiedgroup_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/o3eunifiedgroup endpoint. */
    portal_targetsystem_o3eunifiedgroup_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_o3eunifiedgroup_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3eunifiedgroup_interactive_byid_get(UID_O3EUnifiedGroup: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
}
export interface portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_o3edl_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_o3edl_mailboxes_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_get_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_filtertree_post_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_o3edl_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_o3emailbox_get_args {
    /** Filters accounts for main and sub identities associated with the specified identity */ UID_PersonAssociated?: string;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters orphaned accounts */ orphaned?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_o3emailbox_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_o3emailcontact_get_args {
    /** Filters accounts for main and sub identities associated with the specified identity */ UID_PersonAssociated?: string;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters orphaned accounts */ orphaned?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_o3emailcontact_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_o3emailuser_get_args {
    /** Filters accounts for main and sub identities associated with the specified identity */ UID_PersonAssociated?: string;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters orphaned accounts */ orphaned?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_o3emailuser_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_o3eunifiedgroup_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_o3eunifiedgroup_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export declare class V2ApiClientMethodFactory {
    portal_O3EDL_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_O3EDL_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_O3EUnifiedGroup_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_O3EUnifiedGroup_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_o3edl_get(options?: portal_targetsystem_o3edl_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3edl_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_get(/** Unique identifier of the base object */ UID_O3EDL: string, options?: portal_targetsystem_o3edl_mailboxes_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_post(/** Unique identifier of the base object */ UID_O3EDL: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_delete(/** Unique identifier of the base object */ UID_O3EDL: string, /** Exchange Online mailbox */ UID_O3EMailbox: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_get(/** Unique identifier of the base object */ UID_O3EDL: string, options?: portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_datamodel_get(/** Unique identifier of the base object */ UID_O3EDL: string, options?: portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_filtertree_post(/** Unique identifier of the base object */ UID_O3EDL: string, inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_o3edl_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_o3edl_datamodel_get(options?: portal_targetsystem_o3edl_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_o3edl_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3edl_interactive_byid_get(/** Primary key value UID_O3EDL */ UID_O3EDL: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3emailbox_get(options?: portal_targetsystem_o3emailbox_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3emailbox_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3emailbox_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_o3emailbox_datamodel_get(options?: portal_targetsystem_o3emailbox_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_o3emailbox_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3emailbox_interactive_byid_get(/** Primary key value UID_O3EMailbox */ UID_O3EMailbox: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3emailcontact_get(options?: portal_targetsystem_o3emailcontact_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3emailcontact_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3emailcontact_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_o3emailcontact_datamodel_get(options?: portal_targetsystem_o3emailcontact_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_o3emailcontact_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3emailcontact_interactive_byid_get(/** Primary key value UID_O3EMailContact */ UID_O3EMailContact: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3emailuser_get(options?: portal_targetsystem_o3emailuser_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3emailuser_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3emailuser_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_o3emailuser_datamodel_get(options?: portal_targetsystem_o3emailuser_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_o3emailuser_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3emailuser_interactive_byid_get(/** Primary key value UID_O3EMailUser */ UID_O3EMailUser: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3eunifiedgroup_get(options?: portal_targetsystem_o3eunifiedgroup_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3eunifiedgroup_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_o3eunifiedgroup_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_o3eunifiedgroup_datamodel_get(options?: portal_targetsystem_o3eunifiedgroup_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_o3eunifiedgroup_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_o3eunifiedgroup_interactive_byid_get(/** Primary key value UID_O3EUnifiedGroup */ UID_O3EUnifiedGroup: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_O3EDL_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_O3EDL_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_O3EUnifiedGroup_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_O3EUnifiedGroup_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_O3EDL. */
    portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates endpoint. */
    portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates endpoint. */
    portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_O3EUnifiedGroup. */
    portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates endpoint. */
    portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates endpoint. */
    portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_o3edl_get(options?: portal_targetsystem_o3edl_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3edl_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_get(/** Unique identifier of the base object */ UID_O3EDL: string, options?: portal_targetsystem_o3edl_mailboxes_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_post(/** Unique identifier of the base object */ UID_O3EDL: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3edl_mailboxes_delete(/** Unique identifier of the base object */ UID_O3EDL: string, /** Exchange Online mailbox */ UID_O3EMailbox: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_O3EMailbox. */
    portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_get(/** Unique identifier of the base object */ UID_O3EDL: string, options?: portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates endpoint. */
    portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_datamodel_get(/** Unique identifier of the base object */ UID_O3EDL: string, options?: portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates endpoint. */
    portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_filtertree_post(/** Unique identifier of the base object */ UID_O3EDL: string, inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_o3edl_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/o3edl endpoint. */
    portal_targetsystem_o3edl_datamodel_get(options?: portal_targetsystem_o3edl_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_o3edl_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3edl_interactive_byid_get(/** Primary key value UID_O3EDL */ UID_O3EDL: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3emailbox_get(options?: portal_targetsystem_o3emailbox_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3emailbox_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3emailbox_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/o3emailbox endpoint. */
    portal_targetsystem_o3emailbox_datamodel_get(options?: portal_targetsystem_o3emailbox_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_o3emailbox_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3emailbox_interactive_byid_get(/** Primary key value UID_O3EMailbox */ UID_O3EMailbox: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3emailcontact_get(options?: portal_targetsystem_o3emailcontact_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3emailcontact_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3emailcontact_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/o3emailcontact endpoint. */
    portal_targetsystem_o3emailcontact_datamodel_get(options?: portal_targetsystem_o3emailcontact_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_o3emailcontact_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3emailcontact_interactive_byid_get(/** Primary key value UID_O3EMailContact */ UID_O3EMailContact: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3emailuser_get(options?: portal_targetsystem_o3emailuser_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3emailuser_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3emailuser_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/o3emailuser endpoint. */
    portal_targetsystem_o3emailuser_datamodel_get(options?: portal_targetsystem_o3emailuser_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_o3emailuser_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3emailuser_interactive_byid_get(/** Primary key value UID_O3EMailUser */ UID_O3EMailUser: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3eunifiedgroup_get(options?: portal_targetsystem_o3eunifiedgroup_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3eunifiedgroup_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_o3eunifiedgroup_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/o3eunifiedgroup endpoint. */
    portal_targetsystem_o3eunifiedgroup_datamodel_get(options?: portal_targetsystem_o3eunifiedgroup_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_o3eunifiedgroup_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_o3eunifiedgroup_interactive_byid_get(/** Primary key value UID_O3EUnifiedGroup */ UID_O3EUnifiedGroup: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
}
